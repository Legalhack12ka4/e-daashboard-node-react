import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";

function ProductList() {
  const [product, setProduct] = useState([]);
  const navigate = useNavigate();
  useEffect(() => {
    handleFetch();
  }, []);

  const handleFetch = async () => {
    console.log("fetching...");
    let result = await fetch("http://localhost:3001/products", {
      headers: {
        authorization: `bearer ${JSON.parse(localStorage.getItem("token"))}`,
      },
    });
    result = await result.json();
    setProduct(result);
  };

  const deleteProduct = async (id) => {
    console.log(id);
    let result = await fetch(`http://localhost:3001/product/${id}`, {
      method: "Delete",
      headers: {
        authorization: `bearer ${JSON.parse(localStorage.getItem("token"))}`,
      },
    });
    result = await result.json();
    if (result) {
      handleFetch();
    }
  };

  const searchHandle = async (e) => {
    let key = e.target.value;
    if (key) {
      let result = await fetch(`http://localhost:3001/search/${key}`, {
        headers: {
          authorization: `bearer ${JSON.parse(localStorage.getItem("token"))}`,
        },
      });
      result = await result.json();
      if (result) {
        setProduct(result);
      }
    } else {
      handleFetch();
    }
  };

  return (
    <div style={styles.container}>
      <h1 style={styles.heading}>Product List</h1>
      <input type="tex" placeholder="search product" onChange={searchHandle} />
      {product.length === 0 ? (
        <p style={styles.message}>No products available.</p>
      ) : (
        <table style={styles.table}>
          <thead>
            <tr>
              <th style={styles.th}>Name</th>
              <th style={styles.th}>Price</th>
              <th style={styles.th}>Category</th>
              <th style={styles.th}>Company</th>
              <th style={styles.th}>Action</th>
            </tr>
          </thead>
          <tbody>
            {product.map((p) => (
              <tr key={p._id} style={styles.tr}>
                <td style={styles.td}>{p.name}</td>
                <td style={styles.td}>{p.price}</td>
                <td style={styles.td}>{p.category}</td>
                <td style={styles.td}>{p.company}</td>
                <td style={styles.td}>
                  <button onClick={() => deleteProduct(p._id)}>Delete</button>
                  <Link to={`/update/${p._id}`}>Update</Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

const styles = {
  container: {
    padding: "20px",
    maxWidth: "800px",
    margin: "0 auto",
    fontFamily: "Arial, sans-serif",
  },
  heading: {
    textAlign: "center",
    marginBottom: "20px",
  },
  table: {
    width: "100%",
    borderCollapse: "collapse",
    marginTop: "20px",
    boxShadow: "0 0 10px rgba(0, 0, 0, 0.1)",
  },
  th: {
    border: "1px solid #ddd",
    padding: "10px",
    backgroundColor: "#f4f4f4",
    fontWeight: "bold",
    textAlign: "left",
  },
  tr: {
    borderBottom: "1px solid #ddd",
  },
  td: {
    border: "1px solid #ddd",
    padding: "10px",
    textAlign: "left",
  },
  message: {
    textAlign: "center",
    color: "#888",
  },
};

export default ProductList;
