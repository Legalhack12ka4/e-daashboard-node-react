import React, { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom';

function UpdateProduct() {
    const [name, setName] = useState("");
    const [price, setPrice] = useState ("");
    const [category, setCategory] = useState ("");
    const [company, setCompany] = useState ("");
    const [error, setError] = useState(false)
    
    const navigate = useNavigate();
    const parms= useParams();
    useEffect(() => {
        getUpdateProduct(); 
    },[])

const getUpdateProduct = async () => {
    let result = await fetch(`http://localhost:3001/product/${parms.id}`,
        {
            headers: {
                authorization: `bearer ${JSON.parse(localStorage.getItem("token"))}`,
              },
        }
    );
      result = await result.json()
      setName(result.name);
      setPrice(result.price);
      setCategory(result.category);
      setCompany(result.company);
}


    const handleUpdateProduct = async () => {
        if(!name || !price || !category || !company)
            {
                setError(true);
                return false;
            }
        let result = await fetch(`http://localhost:3001/product/${parms.id}`,{
            method: 'put',
            body: JSON.stringify({name, price, category, company}),
            headers: {
              'Content-Type':'application/json',
                authorization: `bearer ${JSON.parse(localStorage.getItem("token"))}`,
            },
        });
          result = await result.json()
          navigate('/')
    }

  return (
    <div>
    <h1>Update Product</h1>
    <div className="register">
      <input className="textbox" type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="Enter Product name" />
       {error && !name && <span style={{color:'red'}}>Name is Reuired</span>}
      <input className="textbox" type="text" value={price} onChange={(e) => setPrice(e.target.value)} placeholder="Enter price" />
      {error && !price && <span style={{color:'red'}}>Price is required</span>}
      <input className="textbox" type="text" value={category} onChange={(e) => setCategory(e.target.value)} placeholder="Enter category" />
      {error && !category && <span style={{color:'red'}}>Catgeory is required</span>}
      <input className="textbox" type="text" value={company} onChange={(e) => setCompany(e.target.value)} placeholder="Enter company" />
      {error && !company && <span style={{color:'red'}}>Company is required</span>}
      <button type="button" onClick={handleUpdateProduct}>Update Product</button>
    </div>
  </div>
  )
}


export default UpdateProduct