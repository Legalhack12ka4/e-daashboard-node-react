import React, { useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";

function Nav() {
  const auth = localStorage.getItem("user");
  const navigate = useNavigate();
  const logout = () => {
    localStorage.clear();
    navigate("/signup");
  };

  return (
    <div>
      <ul className="nav-ul">
        <li>
          <img
            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJ0AAACUCAMAAAC+99ssAAAAbFBMVEU9scj////j4+P09PTx8fH6+vrp6enm5ub39/fs7OwvrsbG5OyIy9rY7PIYqcOa0t9Mtcvg8PTM3OBkvdDy+fus2OLx6Oa719602uNuwNNZuc3Q6O6MxdP38fC94Onq9fjd5+ms0NmZytV+wtHsdbQQAAALv0lEQVR4nM1c6ZarIAwWFVDaWrWrtradzvu/42VRBBXcncsPzpwR5WsgCwmJg10fAOSGAISs810MgOe6AEDXhQC4rgdgOYZ3iI1x2RgMQeDigD32AOBjMHscijEIVmOq79BOmyvU54J8LiTH0Lkc3/c9r9F5rW70mMbjYMR3lIFOmwpIUKH6cT4jhRiDxS8MdCqgiuKYdhBjRilcUSFUxlAiBepcgaR4qFLclxSHDntD0LaxRpy2WK61dY2KKz4nn/S22+1ut8ch+TCI6hphHZ2roXNVdEBBBxyEfQhDHELoy85DGMIA4wBCjDz22K86hNgY+tjD9K8AIe+c3I9ZzJpTNvZ3nh13iY9COg/i38Ee66rvlHMh9p1qLvYxfa7QaXEFGsoVCJwfP8+cRIQQp91IFJH8+0r8K57OFSHiMNnvER2nnaAL/c0o9MrHZcd+M3sM0W2fO93AFIgkPj1vdOaQ0QVZ5wrYXAEfWM01Zd/R/ZL+nKIeYCoRs9sZFMZ9h837bjy6K9zt46HQKhLm+8cVj0cXhozGZRfQLgygx7qg7Bi16eOgGvO+jIQm1/iOfK/+Tj0X1OdSxozkiiJ9xtF4aKJF+TccyRWUy+k4zIBRLgeMy5lcZbKXdkwI0DdYR7kcvJ/OBLIpBIwv5/ZcXIazteYyXOARoMbsu/c3moWN08+5QzhcGnPadunzhiZD4B7Pxsbpl1P+GMoVA1Q462B6mrzfmi3KPoHFAFCtAFeqAIsFhf3LvA2nNxL/XIdxBZXfTJKHgItuwDtdz9LH6TKLquA7fSglUMmBdC5E1xrxuQQeHwKhK5g+B/w5VdgV1yDGWSFm2wCFlykCrgdefL8G+lwVKws8CGsWlIkrPPe0ODaO7+n1c0W5EX11N6p8EjyWXlUJL0uKHpPZcZu6QueK621JdmjAi9N5ugJ8V8PG8e0Ue7+tK5DDLKywy7hierg4rgqOwrsF0mgUXVDhYRafVZOFvyuDo5L5aOWKIGAbsNlRWe4HYH1wFN4dsrn4hGJuv0bRYUHBaqduAY4u7ldyBda5gu47oyYDz03AUeq9FJ4FWONZfu4oj2sqV/hrM4TSboXKFSVrsDOX4Iq2BYXWFSV6IzcTV8gzG7fsK9qBdENwtL1BLVY42QQog67YGByJP5Wu0PddN1eso/gt8DLQiY4KGXpcY50nOnpcC/Ybg6PwLgUTeiETeqJjULq4At8WM9JHtNR06tH8dxClcf+3lm95pQt8LH2F2r4r/YTZ5uvKWnTEbWnc4tni9RfrShtJccu+a9nGn7/Bxg66fmUblxa637agtudXCe8edHCFeiYLDn+0rrx9UGWeCy+Oep7lx7X8z0hHibcXziQoLPe23/j+h+AovATYoim+QYVFZL77aQi6DGp4dK5APwYMr+SxieqN0jZX4JIr4NXw0pmayiDfAB2zBkou5bqC+4RD5rylKnjXybB0s7LW/XDpljKXMXdmt7gi63yBHDm6TWQNeWItmhJWlovvp4Y3lkTXG39BXoUn1GOMBjWxFDoO7HS8WOFRhaHYKArPQsNrS6AjJHKy/eUAe0Vq3oqmcK4o7obp56KjNItOx0fCOR/0ehh21aE1VLmiMEm0eejibH9PQN1gj2Ris6l+Y868AHxs42fQzgNaO/RY3iQ/a35jsc7IuFtnosvfGrpXn86J0o7IOzYa7DPRkZMGr9cDQp5XJZpSuqfe5uFzuSI+K9uu/9QSM7XFPWU1VzyMk8+WKNT0kOjO/cYEScLWqcfs1pmP7lHTLhnwlbtfoav23dXMSrPRHZRtZ9cUYr5fPfJO2eNjGT2TKxTK9cti9kJ2bkRTgttK6IhTiWLBGoNeOpQnWLnvLBQfho6QXeeJqaLcI2OCJRkCjty0aArCvuUYOwgdiQ/g3Q5akYpyByFYemUxf+mLwjqagiA8W44NQ9CJBXy3qCcpR0cQqjUGeaPJLwvCSr8x/a5F+w1AR0q+bFBPUi7h0TYSv4d5GnIlmsIceQfbT+lFR2K59RV49X938n/DnG8RFN7OUldgm6O4Fx0htYmU1PDIQaPciBbpXIF+bMvWg47kqv0GSnjEqZT/bvRJOErLGKPwG8PLdHQq5YDCGhXlHuMjvOTB7h4FMsZo4yU7unp3VbRie4+QtwQ3vpEdVLgigJPR1eAO5F5TL64ot5sSGycXKGgn9t3VZnXZ0NWKii4geUl4NeQp7hfyLcS+E5psKrqactw8lNSr2q79yiB0z0KNplj97GZ0RFFU4h8vDdxh4pUHsoc1V9BThs3/ZURH8pbQiFTqjRclckYoY4x4IrpOviQXCW4Kt0p07AISLHXFdQK6Wghru0tS7zHdHSn33WSuUBhCf7ek3kSG0NGV1+tsBnUnOgVca/ydi5I56C7igl51rhgrjWuG6DhpUurNoRz7fVC7bzwSXY+iIsdZ4GpNJvYdNjnbu9EposSgfGeiu/mlBSXQ2QLGHbSTlFsnTMAtKB5N4cF23zZNC53UEJPFbR86X/qN+b6zneRa6E5nI0MshK4ReX9bPJImdPP40tJIrkZTmIvWIvDaK/uyMMQS6H6Lht943Gl7B+B9LWzMvMN6NKUY56mIojVjjiQNda6Aa3l5pjSqJHWugO7/g457yCRXcCJaApybo9t71cri6raMWdNuju4VKjFGEQ+1OCK23neJX4q5OrbtGh0wW6OLC3njo46mGOXxxujI96rGGEW0Fhojkxujiw519LiOMX5MS1veC7A5IBdshGrxjlv4RfetADZehGqOmxCPrZSSsSUzAoxqPSqNzZn2uIbBKL/iFOE2V7iBMZZQLi1d3N1S7WXkwZOn5abUuSDmu+N6iHWRZoBH7kF3bgo23PjQg4RLtbdhH+GOm5XIcltGXdsFW7ez8qndIeM+qDInynJ/nOSH/vlGtW4epMaTL/PrgX7f2BYGdY5J/5TDW/dBhvyqd8igdlc78G+2gyNxsv1SzeBVij5lbnF5V1u/594TtSfLte7v7xv3jRs3K9c6Pw9szZuVUGZO86TpAVce1mvky6CUK6tnbJUZt0NuFazWwlbGVr0LBQE3zOdptOjFc9+VtPt2xpbRkFq7kax9zx3XGawCXbia76avNW/hixhjIw3P2ybLrdnIF4o0vDoXz+vIY0R/srbkFBoytkQOaJmxRXdm+gdrG3/0HFAhUbryZ+Fzc3gsXbCj1kJ3xtbWW49p/66MrVZyKu/OayVrG8BlfitDNayiKdwHpecxGs3kVcDlZ3OdivoWfl0vILTZUkuDcz5y66OqXkCZm2LKKt8wNerRqEACm1zRzshfOd29btHDVunLVOPD2+jsfw9slb7MlSC2oB7ZTa1pFH5Xpx6LhLdqy7gSXW2j+ArXVNUZVk6RIs4jEHNhLec9FKBa54pmTSNbZHQJcH2Vvkz1oMqiUJ8Vq2icPrCjHlSNx17TiNdHea91DmLej/5KX4YahXVNo1VMAhJ9B1TnkxEBSc5WpS9wW94mIKcDMFb6gjIiMKDSFwjTbGHREv1+htY06qhQgqoKJaJARFi8Fq24lKeFX88FtbnUWnuah8xSS+ua7peKeRLyZJQaWP+uu2alqIKkVPqCj9MShZcIyRLcVekL61whYozDa3l63gKVyKLs5nn2uVQrAHeeK3SukPXvzvPqVhES72A4pv5dmyv0qpB6HaEi/Jm8vnRN7wWoqkK25woacw2r9FVW3wr4zXhKzVs2hT9I9Hvj0ygZ7LZKX+1oiq3+nVKzEpyP40ovMp/uBV0HVXJt1r+bUAXXe++O8dCSmiTKLw+/mFQFd1xVSKWeLU6PWWyJd5VEi7PvZ3qt1NpToZ7ZlKqQzepbbAyvyEv/et+++xMr2drEyNI+I+f0+/M4A17JlX0HaF4RoFeFrOfy9EpfVq6ADa4Qr2N5rvPdT/KqqUg4MiffH3epy6v9sXxJ8Zvox2xzhepcrP4dHM8VsLuCcEHHfNIkSdL0DMH1aq8gPJgrjFvSa1T/GFIOWnhCusf0fKJzrn/csNUHeBC36gAAAABJRU5ErkJggg=="
            width={40}
            height={40}
            alt="Header logo"
            style={{borderRadius: '50%'}}
          />
          {auth ? (
            <>
              <Link to="/">Products</Link>
              <Link to="/add">Add Product</Link>
              <Link to="/update">Update Product</Link>
              <Link to="/profile">Profile</Link>
              <Link to="/signup" onClick={logout}>
                Logout ({JSON.parse(auth).name})
              </Link>
            </>
          ) : (
            <>
              <Link to="/signup">Sign Up</Link>
              <Link to="/login">Login</Link>
            </>
          )}
        </li>
      </ul>
    </div>
  );
}

export default Nav;
